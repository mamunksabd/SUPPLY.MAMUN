ACGC Premium AI Website - Vercel Ready Package

What is inside:
- index.html
- images folder
- api/chat.js
- api/tts.js
- vercel.json
- .env.example

How to deploy on Vercel:
1. Upload the whole folder to Vercel.
2. In Vercel project settings, add environment variable:
   OPENAI_API_KEY = your real OpenAI API key
3. Redeploy.
4. Optional: Replace Formspree endpoint in index.html.

Notes:
- This package is designed for Vercel single-project deploy.
- AI chat uses /api/chat.
- Voice uses /api/tts.
- If voice is blocked on mobile, first tap the AI button, then send a message.
